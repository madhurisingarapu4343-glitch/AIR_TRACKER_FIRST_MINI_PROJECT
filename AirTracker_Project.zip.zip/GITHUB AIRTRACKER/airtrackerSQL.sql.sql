create database Airtracker;
use Airtracker
CREATE TABLE flights (
    flight_number VARCHAR(20),
    call_sign VARCHAR(20),
    status VARCHAR(20),
    airline VARCHAR(10),
    origin_iata VARCHAR(10),
    destination_iata VARCHAR(10),
    scheduled_time DATETIME,
    revised_time DATETIME,
    aircraft_registration VARCHAR(20)
);

CREATE TABLE airport (
    iata VARCHAR(10) PRIMARY KEY,
    name VARCHAR(100),
    city VARCHAR(50),
    country VARCHAR(50)
);

CREATE TABLE airport_delay (
    airport VARCHAR(10),
    total_flights INT,
    canceled_flights INT,
    delayed_flights INT
);

CREATE TABLE aircraft (
    registration VARCHAR(20) PRIMARY KEY,
    model VARCHAR(50)
);

SELECT COUNT(*) FROM flights;
SELECT * FROM flights LIMIT 5;

SELECT COUNT(*) FROM airport;
SELECT * FROM flights limit 5;

SELECT COUNT(*) FROM aircraft;
SELECT * FROM aircraft limit 5;

SELECT COUNT(*) FROM airport_delay;
SELECT * FROM aircraft limit 5;

#Show the total number of flights for each aircraft model, listing the model and its count.

SELECT a.model, COUNT(*) AS total_flights  
FROM flights f  
JOIN aircraft a  
ON f.aircraft_registration = a.registration  
GROUP BY a.model  
ORDER BY total_flights DESC;

#List all aircraft (registration, model) that have been assigned to more than 5 flights.

SELECT a.registration, a.model, COUNT(*) AS flight_count
FROM flights f
JOIN aircraft a
ON f.aircraft_registration = a.registration
GROUP BY a.registration, a.model
HAVING COUNT(*) > 5;

#For each airport, display its name and the number of outbound flights, 
#but only for airports with more than 5 flights.

SELECT ap.name AS airport_name, COUNT(*) AS outbound_flights
FROM flights f
JOIN airport ap
ON f.origin_iata = ap.iata_code
GROUP BY ap.name
HAVING COUNT(*) > 5;

describe AIRPORT;

#Find the top 3 destination airports (name, city) by number of arriving flights, sorted by count descending
 
SELECT 
    ap.name AS airport_name,
    ap.city,
    COUNT(*) AS total_arrivals
FROM flights f
JOIN airport ap
ON f.destination_iata = ap.iata_code
GROUP BY ap.name, ap.city
ORDER BY total_arrivals DESC
LIMIT 3;

#Show for each flight: number, origin, destination, and a label 'Domestic' or 'International' 
#using CASE WHEN on country match.

SELECT 
    f.flight_number,
    o.name AS origin_airport,
    d.name AS destination_airport,
    CASE 
        WHEN o.country = d.country THEN 'Domestic'
        ELSE 'International'
    END AS flight_type
FROM flights f
JOIN airport o 
ON f.origin_iata = o.iata_code
JOIN airport d 
ON f.destination_iata = d.iata_code;

#Show the 5 most recent arrivals at “DEL” airport including flight number, 
#aircraft, departure airport name, and arrival time, ordered by latest arrival.

SELECT 
    f.flight_number,
    f.aircraft_registration,
    a.name AS departure_airport,
    f.scheduled_time AS arrival_time
FROM flights f
JOIN airport a
ON f.origin_iata = a.iata_code
WHERE f.destination_iata = 'DEL'
ORDER BY f.scheduled_time DESC
LIMIT 5;

# Find all airports with no arriving flights (never used as a destination in flights table).

SELECT *
FROM airport a
WHERE a.iata_code NOT IN (
    SELECT DISTINCT destination_iata
    FROM flights
);

SELECT 
    a.name AS airport_name,
    a.city,
    COUNT(f.destination_iata) AS total_arrivals
FROM airport a
LEFT JOIN flights f                                #using left join
    ON a.iata_code = f.destination_iata
GROUP BY a.name, a.city
HAVING total_arrivals = 0;

#For each airline, count the number of flights by status (e.g., 'On Time', 'Delayed', 'Cancelled') using CASE WHEN.
 
SELECT 
    airline,
    COUNT(CASE WHEN status = 'Departed' THEN 1 END) AS on_time,
    COUNT(CASE WHEN status = 'Delayed' THEN 1 END) AS delayed,
    COUNT(CASE WHEN status = 'Canceled' THEN 1 END) AS cancelled
FROM flights
GROUP BY airline
ORDER BY airline;

SELECT airline, 
SUM(CASE WHEN status='Departed' THEN 1 ELSE 0 END) AS on_time,
 SUM(CASE WHEN status='Delayed' THEN 1 ELSE 0 END) AS "delayed",
 SUM(CASE WHEN status='Canceled' THEN 1 ELSE 0 END) AS cancelled 
 FROM flights 
 GROUP BY airline 
 ORDER BY airline;

SELECT DISTINCT status FROM flights;

SELECT airline,
       SUM(CASE WHEN status='Departed' THEN 1 ELSE 0 END) AS on_time,
       SUM(CASE WHEN status='Delayed' THEN 1 ELSE 0 END) AS delayed,
       SUM(CASE WHEN status IN ('Canceled', 'CanceledUncertain') THEN 1 ELSE 0 END) AS cancelled
FROM flights
GROUP BY airline
ORDER BY airline;

SELECT airline,
       SUM(CASE WHEN status='Departed' THEN 1 ELSE 0 END) AS `on_time`,
       SUM(CASE WHEN status='Delayed' THEN 1 ELSE 0 END) AS `delayed`,
       SUM(CASE WHEN status IN ('Canceled', 'CanceledUncertain') THEN 1 ELSE 0 END) AS `cancelled`
FROM flights
GROUP BY airline
ORDER BY airline;

#Show all cancelled flights, with aircraft and both airports, ordered by departure time descending.

SELECT 
    flight_number,
    aircraft_registration,
    origin_iata AS origin_airport,
    destination_iata AS destination_airport,
    scheduled_time
FROM flights
WHERE status IN ('Canceled', 'CanceledUncertain')
ORDER BY scheduled_time DESC;

# List all city pairs (origin-destination) that have more than 2 different aircraft models operating
# flights between them.

SELECT 
    f.origin_iata AS origin,
    f.destination_iata AS destination,
    COUNT(DISTINCT a.model) AS aircraft_model_count
FROM flights f
JOIN aircraft a ON f.aircraft_registration = a.registration
GROUP BY f.origin_iata, f.destination_iata
HAVING COUNT(DISTINCT a.model) > 2
ORDER BY aircraft_model_count DESC;

#For each destination airport, compute the % of delayed flights (status='Delayed') 
#among all arrivals, sorted by highest percentage. 

SELECT 
    f.destination_iata AS destination,
    COUNT(*) AS total_arrivals,
    SUM(CASE WHEN f.status = 'Delayed' THEN 1 ELSE 0 END) AS delayed_count,
    ROUND((SUM(CASE WHEN f.status = 'Delayed' THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS delayed_percentage
FROM flights f
GROUP BY f.destination_iata
HAVING COUNT(*) > 0
ORDER BY delayed_percentage DESC;

SELECT 
    ap.name AS airport_name,
    COUNT(*) AS total_arrivals,
    SUM(CASE WHEN f.status = 'Delayed' THEN 1 ELSE 0 END) AS delayed_count,
    ROUND((SUM(CASE WHEN f.status = 'Delayed' THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS delayed_percentage
FROM flights f
JOIN airport ap ON f.destination_iata = ap.iata_code
GROUP BY ap.name
HAVING COUNT(*) > 0
ORDER BY delayed_percentage DESC;

password=""