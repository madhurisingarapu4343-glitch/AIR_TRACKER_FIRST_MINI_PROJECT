import streamlit as st
import mysql.connector
import pandas as pd

# ---------------- DATABASE CONNECTION ----------------
conn = mysql.connector.connect(
    host="localhost",
    user="testuser",
    password="1234",
    database="airtracker"
)

st.title("✈️ Air Tracker Dashboard")

# ---------------- OVERVIEW ----------------
st.header("📊 Overview")
col1, col2, col3 = st.columns(3)

total_flights = pd.read_sql_query("SELECT COUNT(*) as count FROM flights", conn)
col1.metric("Total Flights", total_flights['count'][0])

total_airports = pd.read_sql_query(
    "SELECT COUNT(DISTINCT origin_iata) as count FROM flights",
    conn
)
col2.metric("Total Airports", total_airports['count'][0])

avg_delay = pd.read_sql_query(
    """
    SELECT AVG(TIMESTAMPDIFF(MINUTE, scheduled_time, revised_time)) as avg_delay
    FROM flights
    WHERE revised_time IS NOT NULL
    """,
    conn
)
col3.metric("Avg Delay (mins)", round(avg_delay['avg_delay'][0], 2))

# ---------------- SEARCH & FILTER ----------------
st.header("🔍 Search & Filter Flights")
search = st.text_input("Search by Flight Number or Airline")
status_filter = st.selectbox("Filter by Status", ["All", "Departed", "Delayed", "Canceled"])
origin_filter = st.text_input("Filter by Origin Airport (IATA)")

query = "SELECT * FROM flights WHERE 1=1"
if search:
    query += f" AND (flight_number LIKE '%{search}%' OR airline LIKE '%{search}%')"
if status_filter != "All":
    query += f" AND status = '{status_filter}'"
if origin_filter:
    query += f" AND origin_iata LIKE '%{origin_filter}%'"

df = pd.read_sql_query(query, conn)
st.dataframe(df)

# ---------------- STATUS CHART ----------------
st.header("📊 Flight Status Distribution")
status_df = pd.read_sql_query(
    "SELECT status, COUNT(*) as count FROM flights GROUP BY status",
    conn
)
st.bar_chart(status_df.set_index("status"))

# ---------------- AIRPORT DETAILS ----------------
st.header("📍 Airport Details")
airport = st.text_input("Enter Airport Code (IATA)")

if airport:
    airport_df = pd.read_sql_query(
        f"""
        SELECT * FROM flights
        WHERE origin_iata = '{airport}'
        OR destination_iata = '{airport}'
        """,
        conn
    )
    st.write("Flights for this Airport")
    st.dataframe(airport_df)

    # Airport Info
    airport_info = pd.read_sql_query(
        f"""
        SELECT name AS airport_name, city, country
        FROM airport
        WHERE iata_code = '{airport}'
        """,
        conn
    )
    st.write("Airport Info")
    st.dataframe(airport_info)

# ---------------- DELAY ANALYSIS ----------------
st.header("⏱ Top 10 Airports by Delay")
delay_df = pd.read_sql_query(
    """
    SELECT origin_iata AS airport,
           AVG(TIMESTAMPDIFF(MINUTE, scheduled_time, revised_time)) AS avg_delay
    FROM flights
    WHERE revised_time IS NOT NULL
    GROUP BY origin_iata
    ORDER BY avg_delay DESC
    LIMIT 10
    """,
    conn
)
st.bar_chart(delay_df.set_index("airport"))

# ---------------- ROUTE LEADERBOARD ----------------
st.header("🏆 Route Leaderboards")
busiest_routes = pd.read_sql_query(
    """
    SELECT origin_iata, destination_iata, COUNT(*) as total_flights
    FROM flights
    GROUP BY origin_iata, destination_iata
    ORDER BY total_flights DESC
    LIMIT 5
    """,
    conn
)
st.subheader("Top 5 Busiest Routes")
st.dataframe(busiest_routes)

delayed_airports = pd.read_sql_query(
    """
    SELECT origin_iata,
           AVG(TIMESTAMPDIFF(MINUTE, scheduled_time, revised_time)) as avg_delay
    FROM flights
    WHERE revised_time IS NOT NULL
    GROUP BY origin_iata
    ORDER BY avg_delay DESC
    LIMIT 5
    """,
    conn
)
st.subheader("Most Delayed Airports")
st.dataframe(delayed_airports)

# ---------------- AIRCRAFT DETAILS ----------------
st.header("✈️ Aircraft Details")
aircraft_df = pd.read_sql_query(
    """
    SELECT f.flight_number, a.model, a.manufacturer,
           o.name AS origin_airport, d.name AS destination_airport
    FROM flights f
    JOIN aircraft a ON f.aircraft_registration = a.registration
    JOIN airport o ON f.origin_iata = o.iata_code
    JOIN airport d ON f.destination_iata = d.iata_code
    LIMIT 10
    """,
    conn
)
st.dataframe(aircraft_df)

# ---------------- AIRPORT DELAY TABLE ----------------
st.header("⏱ Airport Delay Table")
# Recalculating average delay from flights instead of airport_delay table
delay_table = pd.read_sql_query(
    """
    SELECT origin_iata AS airport,
           AVG(TIMESTAMPDIFF(MINUTE, scheduled_time, revised_time)) AS avg_delay
    FROM flights
    WHERE revised_time IS NOT NULL
    GROUP BY origin_iata
    ORDER BY avg_delay DESC
    LIMIT 10
    """,
    conn
)
st.bar_chart(delay_table.set_index("airport"))