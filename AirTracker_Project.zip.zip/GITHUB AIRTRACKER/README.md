# Air Tracker: Flight Analytics

## Objective
This project manages, analyzes, and visualizes flight data from the AeroDataBox API.
It shows flights, airports, delays, aircraft details, and routes in an interactive Streamlit dashboard.

## Features
- Overview: Total Flights, Airports, Avg Delay
- Flight search & filter by number, airline, origin, and status
- Flight status distribution chart
- Top delayed airports chart
- Busiest routes leaderboard
- Airport details viewer
- Aircraft details table

## How to Run
1. Install Python packages: 
   pip install -r requirements.txt
2. Run the Streamlit app:
   streamlit run AIRTRACKER_STREAMLITFINAL.py
3. Open the app in your browser and explore flights, airports, and delays.

## Screenshots
(Place screenshots of Overview, Flight Status, Top Delayed Airports, Busiest Routes, and Airport Details here)
